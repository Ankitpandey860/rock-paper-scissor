let userScore = 0;
let computerScore = 0;
let playerName = "You";
let friendName = "Computer";

function startGame() {
  const name1 = document.getElementById("player1").value.trim();
  const name2 = document.getElementById("player2").value.trim();

  playerName = name1 || "You";
  friendName = name2 || "Computer";

  document.getElementById("user-label").innerText = playerName;
  document.getElementById("friend-label").innerText = friendName;

  document.getElementById("score-board").style.display = "block";
  document.getElementById("choices").style.display = "block";
}

function play(userChoice) {
  const choices = ["rock", "paper", "scissors"];
  const computerChoice = choices[Math.floor(Math.random() * 3)];

  const result = getResult(userChoice, computerChoice);
  updateScore(result);
  showResult(userChoice, computerChoice, result);
}

function getResult(user, computer) {
  if (user === computer) return "draw";
  if (
    (user === "rock" && computer === "scissors") ||
    (user === "paper" && computer === "rock") ||
    (user === "scissors" && computer === "paper")
  ) return "win";
  return "lose";
}

function updateScore(result) {
  if (result === "win") userScore++;
  if (result === "lose") computerScore++;

  document.getElementById("user-score").innerText = userScore;
  document.getElementById("computer-score").innerText = computerScore;
}

function showResult(user, computer, result) {
  const resultText = {
    win: `${playerName} wins! 🎉`,
    lose: `${friendName} wins! 😢`,
    draw: `It's a draw! 🤝`,
  };

  const resultDisplay = document.getElementById("result");
  resultDisplay.innerText = `${playerName} chose ${user}, ${friendName} chose ${computer}. ${resultText[result]}`;
  resultDisplay.classList.remove("fade-in"); // reset
  void resultDisplay.offsetWidth; // trigger reflow
  resultDisplay.classList.add("fade-in");
}
